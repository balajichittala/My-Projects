package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class EmployeeMergeDemo {
public static void main(String[] args) {
	SessionFactory session_factory=new Configuration().configure().buildSessionFactory();
	
	//Retrieve object from database
	Session session=session_factory.getCurrentSession();
	session.beginTransaction();
	
	Employee e=(Employee)session.get(Employee.class, 24);
	System.out.println(e);
	session.getTransaction().commit();
	
	session.close();
	
	//merge object
	e.setEmp_name("Ramesh");
	Session session2=session_factory.getCurrentSession();
	session2.beginTransaction();
	
	Employee e2=(Employee)session2.merge(e);
	System.out.println(e2);
	session2.getTransaction().commit();
	session2.close();

	//evict object and saveorUpdate
	Session session3=session_factory.getCurrentSession();
	session3.beginTransaction();
	session3.evict(e);
	e.setEmp_name("rama");
	session3.saveOrUpdate(e);
	session3.getTransaction().commit();
	session3.close();

	//persist to save object
	Session session4=session_factory.getCurrentSession();
	session4.beginTransaction();
	Employee e4=new Employee();
	e4.setEmp_name("sunil");
	session4.persist(e4);
	session4.getTransaction().commit();
	session4.close();
}
}
