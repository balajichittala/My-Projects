package com.gaurav.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.gaurav.dao.*;
import com.gaurav.model.*;

public class Test {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");

		EmployeeDao dao = (EmployeeDao) ctx.getBean("edao");
		int status;
		status=dao.saveEmployee(new Employee(1,"basha",1000000,"usa"));
		status=dao.saveEmployee(new Employee(2,"ram",5,"bhimavaram"));
		status=dao.saveEmployee(new Employee(3,"suresh",10,"jupeter"));
		  System.out.println(status);
		 

		/*
		 * int status=dao.updateEmployee(new
		 * Employee(1015,"Deepa Rawal Das",85000,"Manesar"));
		 * System.out.println(status);
		 */

		/*
		 * Employee e=new Employee(); e.setEno(1015); int status=dao.deleteEmployee(e);
		 * System.out.println(status);
		 */
		 

	}

}