package src.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table
public class Address {
	@Id
	@Column
int hno;
	@Column
String line;
	@Column
String city;
	@Column
String state;

public Address(){	
}

public Address(int hno, String line, String city, String state) {
	super();
	this.hno = hno;
	this.line = line;
	this.city = city;
	this.state = state;
}

public int getHno() {
	return hno;
}

public String getLine() {
	return line;
}

public String getCity() {
	return city;
}

public String getState() {
	return state;
}

}
