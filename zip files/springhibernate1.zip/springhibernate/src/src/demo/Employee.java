package src.demo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table
public class Employee {
	@Id
	@Column
int eno;
	@Column
String ename;
	@Column
int salary;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="hno")
Address address;
	
public Employee(int eno, String ename, int salary, Address address) {
	super();
	this.eno = eno;
	this.ename = ename;
	this.salary = salary;
	this.address = address;
}
public int getEno() {
	return eno;
}

public String getEname() {
	return ename;
}

public int getSalary() {
	return salary;
}

public Address getAddress() {
	return address;
}

}
