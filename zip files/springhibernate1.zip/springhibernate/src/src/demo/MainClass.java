package src.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		 SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Employee.class).addAnnotatedClass(Address.class).buildSessionFactory(); 
		 Session session=factory.getCurrentSession();
		 session.beginTransaction();
	        	       
		 ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		Address addr=(Address)context.getBean("aBean");
		System.out.println("HNO : "+addr.getHno());
		System.out.println("Address Line : "+addr.getLine());
		System.out.println("City : "+addr.getCity());
		System.out.println("state : "+addr.getState());
		
		Employee e=(Employee)context.getBean("eBean");
		System.out.println("Eno : "+e.getEno());
		System.out.println("Name : "+e.getEname());
		System.out.println("salary : "+e.getSalary());
		System.out.println("Address : "+e.getAddress().getHno()+"\t"+e.getAddress().getLine()+"\t"+e.getAddress().getCity()+"\t"+e.getAddress().getState());
		
		session.save(addr);
        session.save(e);
        session.getTransaction().commit();
	}
}