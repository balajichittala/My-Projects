package com.beans;
import java.util.*;
public class Employee
 {
   int eno;
   String name;
   Map<Integer,String> mobileNos;
   
   public Employee() {}

public int getEno() {
	return eno;
}

public void setEno(int eno) {
	this.eno = eno;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Map<Integer, String> getMobileNos() {
	return mobileNos;
}

public void setMobileNos(Map<Integer, String> mobileNos) {
	this.mobileNos = mobileNos;
}
   
   
 }
