package com.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass 
{
 public static void main(String[] args)
 {
	 ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
	 Employee e=(Employee)context.getBean("empBean");
	 System.out.println("Eno : "+e.getEno());
	 System.out.println("Ename : "+e.getName());
	 System.out.println("Mobile Nos : "+e.getMobileNos());
 }
}
