import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Scholar;

public class InsertSelect {

	public static void main(String[] args) {
	      
		
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Scholar.class).addAnnotatedClass(ScholarTemp.class).buildSessionFactory();
		
       	Session session=factory.getCurrentSession();
    	session.beginTransaction();
		
		
    	String hql = "insert into ScholarTemp(scholarId, schName)"
    	        + " select scholarId, schName from Scholar";
    	Query query = session.createQuery(hql);
    	int rowsAffected = query.executeUpdate();
    	if (rowsAffected > 0) {
    	    System.out.println(rowsAffected + "(s) were inserted");
    	}

		
       	session.getTransaction().commit();
      
		
        
	}

}
