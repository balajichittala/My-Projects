import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import entity.Scholar;
import java.util.Scanner;


public class HQLNamedParameter {

	public static void main(String[] args) {
	      
		Scanner sc=new Scanner(System.in);
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Scholar.class).buildSessionFactory();
		
       	Session session=factory.getCurrentSession();
    	session.beginTransaction();
		
		
    	String hql = "from Scholar where course like :course";
    	System.out.print("Enter Course to search : ");
    	String keyword =sc.next();
    	Query query = session.createQuery(hql);
    	query.setParameter("course", "%" + keyword + "%");
    	 
    	List<Scholar> list = query.list();
    	System.out.println("----List of Scholars from "+keyword+" course------"); 
    	for (Scholar sch : list) {
    	    System.out.println(sch.getSchName());
    	}
		
       	session.getTransaction().commit();
        sc.close();
		
        
	}
}
