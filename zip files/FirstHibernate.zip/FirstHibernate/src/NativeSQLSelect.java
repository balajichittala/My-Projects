import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Scholar;

public class NativeSQLSelect {

	public static void main(String[] args) {
	      
		
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Scholar.class).buildSessionFactory();
		
       	Session session=factory.getCurrentSession();
    	session.beginTransaction();
		
		
    	
    	SQLQuery query = session.createSQLQuery("select scholarId, schName, city from scholar");
    	List<Object[]> rows = query.list();
    	for(Object[] row : rows){
    		Scholar sch = new Scholar();
    		sch.setScholarId(Integer.parseInt(row[0].toString()));
    		sch.setSchName(row[1].toString());
    		sch.setCity(row[2].toString());
    		System.out.println(sch);
    	}

    	
       	
       	session.getTransaction().commit();
      
		
        
	}



}
