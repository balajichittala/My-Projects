package entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="scholar")
public class Scholar 
{
	@Id
	@Column
	@GeneratedValue (strategy= GenerationType.SEQUENCE, generator="idSeqGen")
	@SequenceGenerator(allocationSize=1, name="idSeqGen", sequenceName ="id_seq")
	int scholarId;
    @Column(length=15)
    String schName;
    @Column(length=15)
    String course;
    @Column(length=15)
    String city;
     
    public Scholar() {}

	public Scholar(int scholarId, String schName, String course, String city) {
		super();
		this.scholarId = scholarId;
		this.schName = schName;
		this.course = course;
		this.city = city;
	}
	
	public Scholar(String schName, String course, String city) {
		super();
		this.schName = schName;
		this.course = course;
		this.city = city;
	}

	public int getScholarId() {
		return scholarId;
	}

	public void setScholarId(int scholarId) {
		this.scholarId = scholarId;
	}

	public String getSchName() {
		return schName;
	}

	public void setSchName(String schName) {
		this.schName = schName;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Scholar [scholarId=" + scholarId + ", schName=" + schName + ", course=" + course + ", city=" + city
				+ "]";
	}
    
	
	
	

}
