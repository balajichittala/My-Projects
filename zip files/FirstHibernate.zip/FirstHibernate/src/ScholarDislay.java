import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import entity.Scholar;


public class ScholarDislay {

	public static void main(String[] args) {
	      
	
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Scholar.class).buildSessionFactory();
		
       	Session session=factory.getCurrentSession();
    	session.beginTransaction();
		
		
       	String hql = "from Scholar"; //Write hql statement
       	Query query = session.createQuery(hql); //create Query object
       	List<Scholar> list =query.list();//call appropriate method 
       	System.out.println("------Scholar Names-------------");
       	for (Scholar scholar : list) {
       	    System.out.println(scholar.getSchName());
       	}

		
       	session.getTransaction().commit();
      
		
        
	}


}
