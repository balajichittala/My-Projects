


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="scholar_temp")
public class ScholarTemp 
{
	
	@Id
	@Column
	int scholarId;
    @Column(length=15)
    String schName;
     
    public ScholarTemp() {}

	public ScholarTemp(int scholarId, String schName) {
		super();
		this.scholarId = scholarId;
		this.schName = schName;
		
	}
	
	public ScholarTemp(String schName) {
		super();
		this.schName = schName;
		
	}

	public int getScholarId() {
		return scholarId;
	}

	public void setScholarId(int scholarId) {
		this.scholarId = scholarId;
	}

	public String getSchName() {
		return schName;
	}

	public void setSchName(String schName) {
		this.schName = schName;
	}

	

	
	
	

}
