package Entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="pro1_many")
public class Project {
   @Id
   @GeneratedValue
   @Column
   int projectId;
      
	@Column(length=15)
    String projectName;
    
    @Column(length=15)
    String projectLocation;
    
    @ManyToOne(cascade= {CascadeType.ALL})
    Employee Employee;
    
    public Project(){    	
    }

	public Project( String projectName, String projectLocation) {
		super();
		this.projectName = projectName;
		this.projectLocation = projectLocation;
	}

	public Employee getEmployee() {
		return Employee;
	}

	public void setEmployee(Employee employee) {
		Employee = employee;
	}
	
	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectLocation() {
		return projectLocation;
	}

	public void setProjectLocation(String projectLocation) {
		this.projectLocation = projectLocation;
	}

	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectName=" + projectName + ", projectLocation="
				+ projectLocation + "]";
	}
    
    
}
