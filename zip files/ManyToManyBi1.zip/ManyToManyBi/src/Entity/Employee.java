package Entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.util.*;

@Entity
@Table(name="emp1_many")
public class Employee {
    @Id
    @GeneratedValue
    @Column
    int eno;
     
    @Column(length=15)
    String ename;

    @ManyToMany(cascade={CascadeType.ALL})
    @JoinTable(name="employee_project_many",joinColumns=@JoinColumn(name="eno"),inverseJoinColumns=@JoinColumn(name="projectId"))
    Set<Project> projectSet= new HashSet<>();
    
    public Set<Project> getProjectSet() {
		return projectSet;
	}
	public void setProjectSet(Set<Project> projectSet) {
		this.projectSet = projectSet;
	}
	public Employee(){   	
    }
	
	public Employee( String ename) {
		super();
	this.ename = ename;
	
	}
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
    
    
}
