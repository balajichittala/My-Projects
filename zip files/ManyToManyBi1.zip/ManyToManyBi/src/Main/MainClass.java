package Main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import Entity.Employee;
import Entity.Project;

import java.util.*;
public class MainClass {

	public static void main(String[] args) {
	      
		//Creating SessionFactory object
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Employee.class).addAnnotatedClass(Project.class).buildSessionFactory();
		    
		
		//create Session object using SessionFactory object
		Session session=factory.getCurrentSession();
		Employee e1=new Employee("Mani");		
		Project p1=new Project("Pnemo","delhi");
		Project p2=new Project("Online based","chenni");
		Project p3=new Project("Anroid Based","srilanka");
		
		Set<Project> al=new HashSet<>();
		al.add(p1);
		al.add(p2);
		al.add(p3);
		
		e1.setProjectSet(al);
		
		p1.setEmployee(e1);
		p2.setEmployee(e1);
		p3.setEmployee(e1);
		
		Employee e2=new Employee("janu");
		Set<Project> a2=new HashSet<>();
		a2.add(p1);
		a2.add(p2);
		a2.add(p3);
		
		e2.setProjectSet(a2);
	   
		p1.setEmployee(e2);
		p2.setEmployee(e2);
		p3.setEmployee(e2);
			   	
		session.beginTransaction();
		session.save(p1);
		session.save(p2);
		session.save(p3);
		
		session.save(e1);
		session.save(e2);
		session.getTransaction().commit();
		
        System.out.println("trainee Objects are persisted!!");
	}


}
