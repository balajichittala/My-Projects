package main;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="stu")
public class Stu {
	@Id
	@Column
	int s_id;
	@Column
	String name;
	public Stu(int s_id, String name) {
		super();
		this.s_id = s_id;
		this.name = name;
	}
	public int getS_id() {
		return s_id;
	}
	public void setS_id(int s_id) {
		this.s_id = s_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Stu [s_id=" + s_id + ", name=" + name + "]";
	}
	
	
}
