package main;

import java.util.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="students")
public class Student {

		@Id
		@Column
		int s_id;
		@Column
		String name;
		@Temporal(TemporalType.DATE)
		Date dob;
		@Temporal(TemporalType.TIMESTAMP)
		@Column
	    Date dol;
		public Student(int s_id, String name, Date dob, Date dol) {
			super();
			this.s_id = s_id;
			this.name = name;
			this.dob = dob;
			this.dol = dol;
		}
		
		
		public Student() {
			super();
			
		}


		public int getS_id() {
			return s_id;
		}
		public void setS_id(int s_id) {
			this.s_id = s_id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public Date getDob() {
			return dob;
		}
		public void setDob(Date dob) {
			this.dob = dob;
		}
		public Date getDol() {
			return dol;
		}
		public void setDol(Date dol) {
			this.dol = dol;
		}
		@Override
		public String toString() {
			return "Student [s_id=" + s_id + ", name=" + name + ", dob=" + dob + ", dol=" + dol + "]";
		}
		
		
		

}
