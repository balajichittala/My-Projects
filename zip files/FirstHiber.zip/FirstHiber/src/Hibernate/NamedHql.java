package Hibernate;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import main.Student;

public class NamedHql {
	public static void main(String[] args) {

    	
        Configuration cfg=new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(Student.class);
        SessionFactory factory=cfg.buildSessionFactory();         

       Session session=factory.getCurrentSession();        
       session.beginTransaction();
       
       String hql = "from Student where name like :name";
       Query query = session.createQuery(hql);
       String keyword = "pur";
       query.setParameter("name", "%" + keyword + "%");
        
       List<Student> list = query.list();
        
       for (Student s : list) {
           System.out.println(s.getName());
       }

     
       session.getTransaction().commit();
       

 }
}
