package Hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import main.Student;

public class SearchHql {
	  public static void main(String[] args) {

	    	
	         Configuration cfg=new Configuration();
	         cfg.configure("hibernate.cfg.xml");
	         cfg.addAnnotatedClass(Student.class);
	         SessionFactory factory=cfg.buildSessionFactory();         

	        Session session=factory.getCurrentSession();        
	        session.beginTransaction();
	        
	        String hql = "from Student where name= 'manoj'";
	        Query query = session.createQuery(hql);
	        List<Student> list = query.list();
	         
	        for (Student s : list) {
	            System.out.println(s.getS_id());
	        }
	        session.getTransaction().commit();
	        

	  }

}
