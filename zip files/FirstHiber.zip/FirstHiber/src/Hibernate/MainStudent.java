package Hibernate;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import main.Student;

public class MainStudent {
	public static void main(String args[]){
		
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Student.class).buildSessionFactory();
		factory.openSession();
		Session session=factory.getCurrentSession();
		try{
			Student s=new Student(4,"neeraj",new Date(),new Date());
			session.beginTransaction();
			session.save(s);
			session.getTransaction().commit();
			System.out.println("done");
		}
		finally{
			factory.close();
		}
	}
            
}	