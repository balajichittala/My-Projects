package Hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import main.Employee;

public class EmployeeDisplay {

    public static void main(String[] args) {

    	
         Configuration cfg=new Configuration();
         cfg.configure("hibernate.cfg.xml");
         cfg.addAnnotatedClass(Employee.class);
         SessionFactory factory=cfg.buildSessionFactory();         

        Session session=factory.getCurrentSession();        
        session.beginTransaction();
        
        String hql="from Employee";
        Query query=session.createQuery(hql);
        List<Employee> list=query.list();
        for(Employee employee:list){
        System.out.println(employee);
        }
        session.getTransaction().commit();
        

  }
}