package Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import main.Employee;

public class curd {
    static SessionFactory factory;
    
    static{
    Configuration config=new Configuration();
    config.configure("hibernate.cfg.xml");
     config.addAnnotatedClass(Employee.class);
     factory=config.buildSessionFactory();         
    }
 public    void insert(Employee e){
     Session se=factory.getCurrentSession();
     se.beginTransaction();
     se.save(e);
    se.getTransaction().commit(); 
    System.out.println("details inserted");
}
    public void delete(Employee e){
        Session se=factory.getCurrentSession();
         se.beginTransaction();
         se.delete(e);
        se.getTransaction().commit();
        System.out.println("details deleted");
    }
    public void update(Employee e){
        Session se=factory.getCurrentSession();
         se.beginTransaction();
         se.update(e);
        se.getTransaction().commit();
        System.out.println("details updated");
    }
    public Employee read(int emp_id){

 

        Session se=factory.getCurrentSession();
         se.beginTransaction();
         Employee e=(Employee)se.get(Employee.class, emp_id);
        se.getTransaction().commit();
        System.out.println("details read");
        return e;    
    }
}