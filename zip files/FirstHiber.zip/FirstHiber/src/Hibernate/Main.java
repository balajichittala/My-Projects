package Hibernate;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import main.Employee;

import java.util.Scanner;
public class Main
{
    public static void main(String[] args) {
       /*Configuration config=new Configuration();
         config.configure("hibernate.cfg.xml");
          config.addAnnotatedClass(employee.class);
          SessionFactory factory=config.buildSessionFactory();         */
         
       // Session session=factory.getCurrentSession();
      Scanner sc=new Scanner(System.in);
      Employee emp=new Employee();
      curd ob=new curd();
    
     while(true){
         System.out.println("enter your choice");
         System.out.println("1.insert");
         System.out.println("2.delete");
         System.out.println("3.update");
         System.out.println("4.read");
         System.out.println("5.exit");
         int opt=sc.nextInt();
      switch(opt){
      case 1: 
          System.out.println("enter your name");
          emp.setEmp_name(sc.next());
          System.out.println("enter your salary");
          emp.setEmp_salary(sc.nextInt());
          sc.nextLine();
          System.out.println("enter your city");
          emp.setCity(sc.next());
          ob.insert(emp);
          break;
      case 2:
          System.out.println("enter your id");
          emp.setEmp_id(sc.nextInt());
        emp=(Employee)ob.read(emp.getEmp_id());
         ob.delete(emp); 
         System.out.println("details deleted");
          break;
      case 3:
          System.out.println("enter your id");
          emp.setEmp_id(sc.nextInt());
          emp=(Employee)ob.read(emp.getEmp_id());
          sc.nextLine();
          System.out.println("enter your name");
          emp.setEmp_name(sc.next()); 
          System.out.println("enter your salary");
          emp.setEmp_salary(sc.nextInt());
          sc.nextLine();
          System.out.println("enter your city");
          emp.setCity(sc.next());
          ob.update(emp);
          System.out.println("record updated");
          break;
      case 4:  
          System.out.println("enter your id");
          emp.setEmp_id(sc.nextInt());
        emp=(Employee)ob.read(emp.getEmp_id());
         System.out.println("data found"+emp);
         break;
      case 5:
          System.exit(0);
      }
      }
    }

 

}