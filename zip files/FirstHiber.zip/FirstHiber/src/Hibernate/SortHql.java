package Hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import main.Stu;
import main.Student;

public class SortHql {

public static void main(String[] args) {

    	
        Configuration cfg=new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(Student.class);
        cfg.addAnnotatedClass(Stu.class);
        SessionFactory factory=cfg.buildSessionFactory();         

       Session session=factory.getCurrentSession();        
       session.beginTransaction();
       
       String hql = "from Student order by s_id ";
       
       Query query = session.createQuery(hql);
       List<Student> list = query.list();
      for (Student student : list) {
         System.out.println(student.getName() + "\t - " + student.getDob());
        }
       session.getTransaction().commit();
       

 }
}
