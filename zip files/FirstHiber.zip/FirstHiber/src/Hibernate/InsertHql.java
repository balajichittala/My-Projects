package Hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import main.Stu;
import main.Student;

public class InsertHql {

	public static void main(String[] args) {

    	
        Configuration cfg=new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(Student.class);
        cfg.addAnnotatedClass(Stu.class);
        SessionFactory factory=cfg.buildSessionFactory();         

       Session session=factory.getCurrentSession();        
       session.beginTransaction();
       
       String hql = "insert into Stu (s_id,name)"
    	        + " select s_id,name from Student";
    	Query query = session.createQuery(hql);
    	int rowsAffected = query.executeUpdate();
    	if (rowsAffected > 0) {
    	    System.out.println(rowsAffected + "(s) were inserted");
    	}
       session.getTransaction().commit();
       

 }

}
