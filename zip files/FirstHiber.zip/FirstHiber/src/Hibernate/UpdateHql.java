package Hibernate;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import main.Stu;
import main.Student;

public class UpdateHql {

public static void main(String[] args) {

    	
        Configuration cfg=new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(Student.class);
        cfg.addAnnotatedClass(Stu.class);
        SessionFactory factory=cfg.buildSessionFactory();         

       Session session=factory.getCurrentSession();        
       session.beginTransaction();
       
       String hql = "update Student set name = :name where s_id = :s_id";
       Query query = session.createQuery(hql);
       query.setParameter("name", "padma");
       query.setParameter("s_id", 1);
        
       int rowsAffected = query.executeUpdate();
       if (rowsAffected > 0) {
           System.out.println("Updated " + rowsAffected + " rows.");
       }
       session.getTransaction().commit();
       

 }

}
