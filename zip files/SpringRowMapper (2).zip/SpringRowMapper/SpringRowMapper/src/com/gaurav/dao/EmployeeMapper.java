package com.gaurav.dao;
import com.gaurav.model.*;
import java.sql.ResultSet;  
import java.sql.SQLException;  
import org.springframework.jdbc.core.RowMapper;  
   

public class EmployeeMapper implements RowMapper<Employee> {
	
	public EmployeeMapper(){}
	
	
	    @Override  
	    public Employee mapRow(ResultSet rs, int rownumber) throws SQLException {  
	        Employee e=new Employee();  
	        e.setEno(rs.getInt(1));  
	        e.setEname(rs.getString(2));  
	        e.setSalary(rs.getInt(3));
	        e.setCity(rs.getString(4));
	        return e;  
	    }  
	 
	
}
