package com.gaurav.main;

import java.util.List; 
import com.gaurav.dao.*;
import com.gaurav.model.*;

import org.springframework.context.ApplicationContext;  
import org.springframework.context.support.ClassPathXmlApplicationContext;  
public class Test {  
public static void main(String[] args) {  
    ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");  
    EmployeeDao dao=(EmployeeDao)ctx.getBean("edao1");  
    List<Employee> list=dao.getAllEmployeesRowMapper();  
        
    System.out.println("---------------------Employee Details--------------------------\n");
    for(Employee e:list)  
        System.out.println(e);
    
    System.out.println("---------------------End of Data--------------------------\n");
}  
} 