package com.beans;

public class HelloBean
{
  String msg;
  
  public HelloBean()
  {  }
  
  public void setMsg(String msg)
  {
	  this.msg=msg;
  }
  public String getMsg()
  {
	  return this.msg;
  }
  
  
}
