package com.beans;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class HelloBeanConfig
{
   
	@Bean
	@Scope("prototype")
	public HelloBean helloBean()
	{
		return new HelloBean();
	}
	
	@Bean
	public ByeBean bBean()
	{
		return new ByeBean();
	}
	
}
