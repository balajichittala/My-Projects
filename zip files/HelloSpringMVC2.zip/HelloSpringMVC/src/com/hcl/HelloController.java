package com.hcl;

import java.util.*;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/apps/")
public class HelloController
{

     @RequestMapping("/hello")	
	 public String sendResponse()
	 {
		 return "hello";
	 }
     
     @RequestMapping("/welcome")
     public String welcome(Model m)
     {
    	 student s=new student();
    	 Map<String,Integer> map=new HashMap<String,Integer>();
    	 map.put("coke",100);
    	 map.put("redbull",150);
    	 map.put("lassi",15);  
    	 
     	m.addAttribute("Student", s);
     	m.addAttribute("items", map);
    	 return "welcome";
     }
     @RequestMapping("/show")
     public String welcome(@ModelAttribute("Student") student ob,Model m)
     {
    	 System.out.println(ob.getName());
    	 m.addAttribute("student", ob);
    	 return "show";
     }
	
}
