package com.beans;

public class Employee 
{
 int eno;
 String name;
 Address address;
 
 public Employee() {}

public Employee(int eno, String name, Address address) {
	super();
	this.eno = eno;
	this.name = name;
	this.address = address;
}

public int getEno() {
	return eno;
}

public String getName() {
	return name;
}

public Address getAddress() {
	return address;
}
 
 
}
