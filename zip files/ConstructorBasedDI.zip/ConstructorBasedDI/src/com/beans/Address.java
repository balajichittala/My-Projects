package com.beans;

public class Address
{
   int hno;
   String line1;
   String city;
   
   public Address() {}

   public Address(int hno, String line1, String city) {
	super();
	this.hno = hno;
	this.line1 = line1;
	this.city = city;
    }

public int getHno() {
	return hno;
}

public String getLine1() {
	return line1;
}

public String getCity() {
	return city;
}
   
   
   
   
}
