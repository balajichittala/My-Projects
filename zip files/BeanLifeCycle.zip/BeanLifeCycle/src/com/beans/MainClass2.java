package com.beans;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass2 {

	public static void main(String[] args) {
		
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		FirstBean bean=(FirstBean)context.getBean("firstBean");
		System.out.println("Message : "+bean.getMessage());
		
		bean.setMessage("This is the new Message.");
		System.out.println("New Message : "+bean.getMessage());
		
		FirstBean fb=(FirstBean)context.getBean("firstBean");
		System.out.println("Message : "+fb.getMessage());
		
		
		
		context.registerShutdownHook();
	}

}
