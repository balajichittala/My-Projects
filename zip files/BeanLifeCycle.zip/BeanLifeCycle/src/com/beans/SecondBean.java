package com.beans;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.DisposableBean;

public class SecondBean implements InitializingBean,DisposableBean 
{
  String message;
  
  public SecondBean() {}

  public String getMessage() {
	return message;
   }

   public void setMessage(String message) {
	   this.message = message;
    }
   
   @Override
   public void afterPropertiesSet()//init method--used to initialize bean
   {
	   System.out.println("SecondBean is initializing.");
   }
   @Override
   public void destroy() //destroy method
   {
	   System.out.println("SecondBean is being destroyed...");
   }
  
}
