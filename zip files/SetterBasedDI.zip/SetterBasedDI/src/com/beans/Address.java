package com.beans;

public class Address 
{
  int hno;
  String line1;
  String city;
  
  public Address() {}

public int getHno() {
	return hno;
}
public void setHno(int hno) {
	this.hno = hno;
}

public String getLine1() {
	return line1;
}

public void setLine1(String line1) {
	this.line1 = line1;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}
  
  
  
}
