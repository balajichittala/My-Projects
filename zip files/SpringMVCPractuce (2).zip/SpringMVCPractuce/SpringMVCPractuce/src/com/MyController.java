package com;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;
import bean.Student;

@Controller
public class MyController {

 Student st;
	@RequestMapping("/login")
	public String doreq(){
	
		return "Login";
	
	}
	@RequestMapping("/abc")
	public String docheck(@RequestParam("name") String name,@RequestParam("id") String id,Model mode){
		System.out.println(name);
	 st=new Student();
		st.setId(id);
		st.setName(name);
		mode.addAttribute("sp", st);
		return "abc";
	}
	
	@RequestMapping("/success")
	public String dovisdom(Model mdel){
		//Student st1=new Student();
		System.out.println(st.getId());
		mdel.addAttribute("sp", st);
		return "success";
	}
}
