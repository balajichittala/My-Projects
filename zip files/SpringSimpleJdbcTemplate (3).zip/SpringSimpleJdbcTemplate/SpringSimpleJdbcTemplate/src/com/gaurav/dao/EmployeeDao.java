package com.gaurav.dao;
import com.gaurav.model.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;  
  
public class EmployeeDao {  
private SimpleJdbcTemplate jdbcTemplate;  
  
public void setJdbcTemplate(SimpleJdbcTemplate jdbcTemplate) {  
    this.jdbcTemplate = jdbcTemplate;  
}  
  
public int saveEmployee(Employee e){  
    String query="insert into employee values(?,?,?,?)";  
    return jdbcTemplate.update(query,e.getEno(),e.getEname(),e.getSalary(),e.getCity());  
}  
/*public int updateEmployee(Employee e){  
    String query="update springEmployee set ename='"+e.getEname()+"',salary="+e.getSalary()+" where eno="+e.getEno();  
    return jdbcTemplate.update(query);  
}  
public int deleteEmployee(Employee e){  
    String query="delete from springEmployee where eno="+e.getEno();  
    return jdbcTemplate.update(query);  
} */ 
  
}