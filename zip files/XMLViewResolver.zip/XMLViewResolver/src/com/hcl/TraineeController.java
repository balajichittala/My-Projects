package com.hcl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class TraineeController {



@RequestMapping("/hello")
	public String processRequest()
	{
		return "welcome1";
	}

  @RequestMapping("/bye")
  public String sayBye()
  {
	  return "bye";
  }
}
