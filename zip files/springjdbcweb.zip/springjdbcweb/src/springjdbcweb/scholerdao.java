package springjdbcweb;

public interface scholerdao {
	public int insert(scholer e);

}
