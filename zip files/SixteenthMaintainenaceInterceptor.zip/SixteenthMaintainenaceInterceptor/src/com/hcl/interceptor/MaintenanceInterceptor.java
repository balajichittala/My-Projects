package com.hcl.interceptor;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;


public class MaintenanceInterceptor extends HandlerInterceptorAdapter{

	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

	Calendar cal = Calendar.getInstance();
	System.out.println("--------------"+cal.get(Calendar.DAY_OF_WEEK)+"--------------------");
	if(cal.get(Calendar.DAY_OF_WEEK)==5)
	{
	response.getWriter().println("The website is under maintenance , Please access it during weekdays");
	return false;
	}
	return true;
	
	}
}
