package com;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Transaction;

public class BookDemo {
   public static void main(String[] args) {
	//create session factory from Hibernate configuration
	SessionFactory session_factory=new Configuration().configure().buildSessionFactory();
	
	//create session from sessionfactory
	Session session=session_factory.openSession();
	
	
	Transaction tx=null;
	try{
		tx=session.beginTransaction();
		
		Book book1=new Book();
		book1.setBook_id(107);
		book1.setBook_name("php");
	
		Integer result=(Integer)session.save(book1);
		
		System.out.println("result "+result);
		//save the object
		//session.save(book1);
		
		
		
		Book book2=session.get(Book.class,28);
		
		System.out.println("RETRIEVED   "+book2);
		
		
		//session.delete(book2);
		book1.setBook_name("xyz");;
		//commit the transaction
		tx.commit();
		System.out.println("book object saved........");
	}
	catch(Exception e){
		//if transaction is not done then roll back
		if(tx!=null)
		tx.rollback();
		e.printStackTrace();
	}
	finally {
	//close the session
		session.close();
		session_factory.close();
	}
   }
}
