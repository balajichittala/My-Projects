package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class BookRetiveDemo {
	public static void main(String[] args) {
		
	
SessionFactory session_factory=new Configuration().configure().buildSessionFactory();
Session session=session_factory.openSession();
Transaction tx=null;
try{
	tx=session.beginTransaction();
	Book book1=(Book)session.get(Book.class,103);
	System.out.println("book object retreievd");
	System.out.println(book1);
	tx.commit();
}
catch(Exception e){
if(tx!=null){
	tx.rollback();
	e.printStackTrace();
}
}
finally {
	session.close();
	session_factory.close();
}

}}
