package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class BookDeleteDemo {
	public static void main(String[] args){
		
SessionFactory session_factory=new Configuration().configure().buildSessionFactory();
Session session=session_factory.openSession();
Transaction tx=null;
try{
	tx=session.beginTransaction();
	//Book book1=(Book)session.get(Book.class,103);
	Book book2=new Book(103,"HTML");
	session.delete(book2);
	//System.out.println("book object retreievd");
	//System.out.println(book1);
	System.out.println(book2);
	System.out.println("book deleted............");
	
	tx.commit();
}
catch(Exception e){
if(tx!=null){
	tx.rollback();
	e.printStackTrace();
}
	}
finally {
	session.close();
	session_factory.close();
}
		}
				}
