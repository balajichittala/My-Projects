package bean;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class ProductSavaDemo {
public static void main(String[] args) {
	SessionFactory sf=new Configuration().configure().buildSessionFactory();
	Session ss=sf.getCurrentSession();
	//Transaction tr=null
		/*
		tr=ss.beginTransaction();
		Product p=new Product();
		p.setProduct_name("system");
		p.setProduct_price(50000);
		p.setProduct_category("system");
		ss.save(p);
		tr.commit();
		System.out.println("saved ");
		*/
	Query query=null;
	ss.beginTransaction();
	query=ss.createQuery("from Product");
	List<Product> list_product=query.list();
	System.out.println(list_product);

	
	query=ss.createQuery("select product_name from Product");
	List<Product> name=query.list();
	System.out.println(name);
	
	query=ss.createQuery("delete from Product where product_id= :s");
	query.setInteger("s",41);
	int p=query.executeUpdate();
	System.out.println("ghfsj  "+p);
	
	
	query=ss.createQuery("update Product set product_name= :product_id where product_id= :n");
	query.setString("product_id","nokia");
	query.setInteger("n", 43);
	int res=query.executeUpdate();
	System.out.println(res);
	
	
	query=ss.createQuery("select count(*) from Product");
	
	List<Product> count=query.list();
	System.out.println("count "+count.get(0));
	
	query=ss.createQuery("select max(product_price) from Product");
	List<Product> lo=query.list();
	System.out.println(lo.get(0));
	ss.getTransaction().commit();
	ss.close();
	sf.close();
}
}
