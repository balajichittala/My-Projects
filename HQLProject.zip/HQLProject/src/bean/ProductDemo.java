
    
package bean;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import bean.Product;


public class ProductDemo {


    public static void main(String[] args) {
        // TODO Auto-generated method stub
        SessionFactory session_factory = new Configuration().configure().buildSessionFactory();
        Session session = session_factory.getCurrentSession();
        
        session.beginTransaction();
        Product product1 = new Product();
        product1.setProduct_name("Nokia");
        product1.setProduct_price(3500);
        product1.setProduct_category("mobile");
        
        session.save(product1);
        
        session.getTransaction().commit();
        session.close();
        session_factory.close();
    


}
}







